package com.example.ichords20.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView // Adicionando a importação necessária para TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.ichords20.TelaAcordes
import com.example.ichords20.TelaCifras
import com.example.ichords20.databinding.FragmentDashboardBinding

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val dashboardViewModel =
            ViewModelProvider(this).get(DashboardViewModel::class.java)

        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // Inicializar TextView e Button
        val textView: TextView = binding.textDashboard
        val buttonAcorde: Button = binding.button3
        val buttonCifras: Button = binding.button4

        // Definir o texto do TextView
        dashboardViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        // Configurar o onClickListener para o botão
        buttonAcorde.setOnClickListener {
            openTelaAcordes()
            //openTelaCifras()


        } // Configurar o onClickListener para o botão
        buttonCifras.setOnClickListener {

            openTelaCifras()
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // Método para abrir a TelaAcordes
    private fun openTelaAcordes() {
        val intent = Intent(requireActivity(), TelaAcordes::class.java)
        startActivity(intent)
    }

    // Método para abrir a TelaCifra
    private fun openTelaCifras() {
        val intent = Intent(requireActivity(), TelaCifras::class.java)
        startActivity(intent)
    }
}
